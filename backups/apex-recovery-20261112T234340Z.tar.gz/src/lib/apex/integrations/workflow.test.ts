import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { runUnifiedWorkflow } from "./workflow.ts";
import { assessProposal, paperAutoEligible } from "./gate.ts";
import { SCHEMA_VERSION } from "./contracts.ts";

describe("unified workflow adapters", () => {
  it("invokes every available adapter and refuses an order", () => {
    const result = runUnifiedWorkflow();
    assert.equal(result.executable, false);
    assert.equal(result.paperAutoEligible, false);
    assert.equal(result.liveEnabled, false);
    assert.equal(result.hermesCanApprove, false);
    assert.equal(result.alpacaIsSoleBroker, true);
    assert.equal(result.proposalAccepted, false);
    assert.ok(result.adapters.lean === "invoked");
    assert.ok(result.adapters.backtrader === "invoked");
  });

  it("a hypothesis proposal is not paper-auto eligible", () => {
    const proposal = {
      schemaVersion: SCHEMA_VERSION,
      id: "x",
      originFramework: "tradingagents" as const,
      strategyId: "s",
      strategyVersion: "1",
      instrument: { schemaVersion: SCHEMA_VERSION, symbol: "SPY", venue: "research" },
      direction: "flat" as const,
      ts: new Date().toISOString(),
      sourceDataTs: new Date().toISOString(),
      entryAssumption: "none",
      holdingPeriod: "n/a",
      exitCondition: "n/a",
      estimatedCostBps: 1,
      provenance: "test",
      validationStatus: "hypothesis" as const,
      evidenceIds: ["e"],
      executable: false as const,
    };
    assert.equal(assessProposal(proposal).accepted, false);
    assert.equal(paperAutoEligible(proposal), false);
  });
});
