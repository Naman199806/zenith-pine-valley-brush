# Restore Apex Quant X

Archive: `apex-recovery-full-20261113T000816Z.tar.gz`
SHA-256: see `research/lab/restore-manifest.json` after extract. The archive hash is also printed by `sha256sum` on the file you downloaded.

Node v22.23.3. npm 10.9.9.

## Install

```
tar -xzf apex-recovery-full-YYYYMMDDTHHMMSSZ.tar.gz -C /some/empty/dir
cd /some/empty/dir
npm ci
```

`npm ci` uses `package-lock.json`. `node_modules` is not in the archive.

## Test and build

```
npm test
npx tsc --noEmit
npm run build
```

## Freqtrade state

Closed BTC dry-run trade is in `.runtimes/freqtrade-run/state/dryrun.sqlite`.
Strategy: `.runtimes/freqtrade-run/user_data/strategies/ApexDry.py`.
Config has `dry_run: true`.

Freqtrade is not bundled. The sandbox used Freqtrade 2026.10 on Python 3.12.15.

## Other runtimes, not bundled

- LEAN: pinned QuantConnect launcher, .NET 10, under `.runtimes/src/Lean` in the sandbox
- Backtrader: Python package in `.runtimes/backtrader`
- Hermes: `.runtimes/hermes314` and source under `.runtimes/src/hermes-agent`

## Keys

`.grok/paper-credentials.json` is not in this archive. Add keys only on a host you control. Do not enable PAPER_AUTO. Do not enable live trading.

## Data

Coinbase BTC-USD and ETH-USD daily candles are in `research/data/raw/coinbase/20261112/`.
Yahoo daily files are in `research/data/raw/yahoo/20261112/`.
