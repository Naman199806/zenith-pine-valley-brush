#!/bin/sh
set -eu
echo "BLOCKED_EXTERNAL_HOST"
echo "PAPER_AUTO=false"
echo "LIVE=false"
echo "not installed on Oracle"
exit 0
