export type Proposal = "BUY" | "SELL" | "HOLD" | "NO_TRADE";

export interface Cycle {
  instrument: string;
  proposal: Proposal;
  reason: string;
  paperAuto: false;
  orderSent: false;
}

export function cycle(instrument: string, quantOk: boolean, strategyApproved: boolean): Cycle {
  if (!quantOk || !strategyApproved) {
    return { instrument, proposal: "NO_TRADE", reason: "No approved strategy.", paperAuto: false, orderSent: false };
  }
  return { instrument, proposal: "HOLD", reason: "Approved, but paper auto is off.", paperAuto: false, orderSent: false };
}
