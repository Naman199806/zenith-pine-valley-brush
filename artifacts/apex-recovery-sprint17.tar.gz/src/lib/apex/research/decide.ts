export interface Decision {
  instrument: string;
  action: "BUY" | "SELL" | "HOLD" | "NO_TRADE";
  reason: string;
  quantRejects: boolean;
  riskRejects: boolean;
}

export function decide(input: { instrument: string; quantOk: boolean; riskOk: boolean; strategyApproved: boolean }): Decision {
  if (!input.quantOk) return { ...input, action: "NO_TRADE", reason: "Quant rejected.", quantRejects: true, riskRejects: !input.riskOk };
  if (!input.riskOk) return { ...input, action: "NO_TRADE", reason: "Risk rejected.", quantRejects: false, riskRejects: true };
  if (!input.strategyApproved) return { ...input, action: "NO_TRADE", reason: "No approved strategy.", quantRejects: false, riskRejects: false };
  return { ...input, action: "HOLD", reason: "Approved strategy exists. Still not an order.", quantRejects: false, riskRejects: false };
}
