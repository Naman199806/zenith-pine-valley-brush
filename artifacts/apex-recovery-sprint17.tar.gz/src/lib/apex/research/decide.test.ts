import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { decide } from "./decide.ts";

describe("research decision", () => {
  it("lets quant and risk beat a bullish note", () => {
    const out = decide({ instrument: "BTC-USD", quantOk: false, riskOk: true, strategyApproved: false });
    assert.equal(out.action, "NO_TRADE");
    assert.equal(out.quantRejects, true);
  });

  it("does not turn an unapproved strategy into a buy", () => {
    assert.equal(decide({ instrument: "SPY", quantOk: true, riskOk: true, strategyApproved: false }).action, "NO_TRADE");
  });
});
