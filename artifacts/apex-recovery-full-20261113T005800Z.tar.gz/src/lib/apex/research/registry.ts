export const STATES = ["RESEARCH", "REJECTED", "VALIDATION", "APPROVED"] as const;
export type ResearchState = (typeof STATES)[number];

export function canPromote(state: ResearchState): boolean {
  return state === "VALIDATION";
}
