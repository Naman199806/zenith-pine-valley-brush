import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { canPromote } from "./registry.ts";

describe("research registry", () => {
  it("does not promote research or rejected work", () => {
    assert.equal(canPromote("RESEARCH"), false);
    assert.equal(canPromote("REJECTED"), false);
    assert.equal(canPromote("APPROVED"), false);
    assert.equal(canPromote("VALIDATION"), true);
  });
});
