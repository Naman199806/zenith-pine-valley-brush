# Restore Apex Quant X

Archive name: `apex-recovery-full-YYYYMMDDTHHMMSSZ.tar.gz`
Checksum: `artifacts/apex-recovery.sha256` next to the archive. It is not inside the archive, because putting it inside would change the hash.

Node v22.23.3. npm 10.9.9.

## Install

```
tar -xzf apex-recovery-full-YYYYMMDDTHHMMSSZ.tar.gz -C /some/empty/dir
cd /some/empty/dir
npm ci
npm test
npx tsc --noEmit
npm run build
```

## Freqtrade

State: `.runtimes/freqtrade-run/state/dryrun.sqlite`
Strategy: `.runtimes/freqtrade-run/user_data/strategies/ApexDry.py`
Runtime not bundled: Freqtrade 2026.10, Python 3.12.15.

## Other runtimes, not bundled

- LEAN: .NET 10, pinned launcher
- Backtrader: Python package
- Hermes: Python 3.14 runtime plus source
- TradingAgents: Python 3.11+

## Data

Coinbase daily candles: `research/data/raw/coinbase/20261112/`
BTC-USD sha256 `68c6c73f0cb7552d880c4cf2469b88d8429a54c0a7c0072cbeac23e1ad7cf30e`
ETH-USD sha256 `b928e688f31a9b87ad0962a21524555a913859a7657165f774549701dfa571fa`

## Keys

`.grok/paper-credentials.json` is not included. Do not enable PAPER_AUTO. Do not enable live trading.
