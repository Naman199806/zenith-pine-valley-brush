/** Completed daily bars only. The 2026-11-13 00:00 UTC bar is incomplete. */

export const INCOMPLETE_DAILY_TS = 1762992000;

export function completedBars<T extends { ts: number }>(bars: T[]): T[] {
  return bars.filter((bar) => bar.ts < INCOMPLETE_DAILY_TS);
}
