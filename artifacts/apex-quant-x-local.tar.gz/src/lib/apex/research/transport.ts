export interface TransportRequest {
  model: "grok-4.3";
  runId: string;
  agentId: string;
  asOfUtc: string;
  thesis: string;
  maxTokens: number;
}

export function buildRequest(input: TransportRequest): { url: string; body: string } {
  if (!input.asOfUtc || !input.thesis || !input.runId) throw new Error("missing contract");
  return {
    url: "https://api.x.ai/v1/chat/completions",
    body: JSON.stringify({
      model: input.model,
      max_tokens: input.maxTokens,
      response_format: { type: "json_object" },
      messages: [{ role: "user", content: `run_id=${input.runId} agent=${input.agentId}` }],
    }),
  };
}

export async function sendMock(input: TransportRequest, fetchImpl = fetch): Promise<{ status: number; paid: false }> {
  const req = buildRequest(input);
  const res = await fetchImpl(req.url, { method: "POST", body: req.body });
  return { status: res.status, paid: false };
}
