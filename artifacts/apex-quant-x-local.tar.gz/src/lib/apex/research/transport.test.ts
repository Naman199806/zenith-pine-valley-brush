import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { buildRequest, sendMock } from "./transport.ts";

describe("xai transport", () => {
  it("builds a grok-4.3 json request and uses a mock response", async () => {
    const req = buildRequest({ model: "grok-4.3", runId: "r1", agentId: "Vector", asOfUtc: "2026-11-12T00:00:00Z", thesis: "test", maxTokens: 200 });
    assert.equal(req.url.includes("api.x.ai"), true);
    const out = await sendMock(
      { model: "grok-4.3", runId: "r1", agentId: "Vector", asOfUtc: "2026-11-12T00:00:00Z", thesis: "test", maxTokens: 200 },
      async () => new Response("{}", { status: 200 }),
    );
    assert.equal(out.status, 200);
    assert.equal(out.paid, false);
  });
});
