import { createServer } from "node:http";
import { readFileSync } from "node:fs";
import { btcPacket } from "../src/lib/apex/bots/packet.ts";
import { cycle, ROLES } from "../src/lib/apex/research/roles.ts";
import { runSynthetic } from "../src/lib/apex/runtime/sim.ts";

const mock = { async complete() { return { text: JSON.stringify({ stance: "DEFER" }), tokens: 1 }; } };
const research = await cycle(btcPacket(), mock, { quantOk: true, riskOk: true, strategyApproved: false });
const packet = JSON.parse(readFileSync("/workspace/research/lab/vector-packet.json", "utf8"));
const state = {
  pid: process.pid,
  mode: "REPLAY",
  flags: { EXPERIMENT_ON: false, PAPER_AUTO: false, LIVE: false },
  roles: research.roles,
  noTrade: research.decision,
  synthetic: runSynthetic(),
  edges: ROLES.map((role, i) => ({
    event_id: `sub-${role}`,
    type: "submission",
    source: role,
    destination: "decision",
    timestamp: new Date().toISOString(),
    message: research.roles[i]?.reason || "role result",
    payload: research.roles[i],
  })),
  conversations: [],
  bars: packet.last30,
  paidCalls: 0,
  brokerWrites: 0,
};
const server = createServer((req, res) => {
  if (req.url === "/state") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify(state));
    return;
  }
  res.writeHead(200, { "content-type": "text/html" });
  res.end(readFileSync("/workspace/public/mission.html"));
});
server.listen(4173, "127.0.0.1", () => console.log(JSON.stringify({ pid: process.pid, url: "http://127.0.0.1:4173" })));